import javax.swing.*;
import java.awt.*;
import java.awt.Color;

/**
 * Student class extends {@link Person}.
 * Creating all GUI elements and data for the Student's window.
 * Elements will be orgenized by the given assignment layout.
 * @author Roy Azami and Omri Kellner
 */
public class Student extends Person {
	private String studentID;
	JTextField studentIDField;
	JLabel studentIDSTRLB;

	/**
	 * Parameterized Constructor
	 * @param id Student's ID Number
	 * @param name Student's Name
	 * @param surname Student's Surname
	 * @param cellNumber Student's Cellular Number
	 * @param studentID Student's Student ID Number
	 */
	Student(String id, String name, String surname, String cellNumber, String studentID)
	{
		/*Person Constructor Call*/
		super(id, name, surname, cellNumber);
		this.studentID = studentID;

		/*Initialize Instance Variables*/
		JPanel line = new JPanel(new FlowLayout());

		JLabel personalNumLBL = new JLabel("Student ID ", JLabel.RIGHT);
		personalNumLBL.setPreferredSize(new Dimension(80, 25));

		studentIDField = new JTextField(studentID);
		studentIDField.setPreferredSize(new Dimension(335,25));

		studentIDSTRLB= new JLabel("*");
		studentIDSTRLB.setForeground(Color.red);
		studentIDSTRLB.setPreferredSize(new Dimension(10,25));
		studentIDSTRLB.setVisible(false);

		line.add(personalNumLBL);
		line.add(studentIDField);
		line.add(studentIDSTRLB);

		addToCenter(line);
	}

	/**
	 * Override Parent {@link Person#initEntityLayout}
	 * Sets Student's window GUI components layout.
	 * Adds the layout to the Central Panel
	 */
	@Override
	protected void initEntityLayout() {
		centerPanel = new JPanel(new GridLayout(5,1,0,10));
		add(centerPanel, BorderLayout.CENTER);
	}

	/**
	 * Override Parent {@link Person#getEntityTitle}
	 * Student's window title
	 * @return The Student's window title
	 */
	@Override
	protected String getEntityTitle()
	{
		return "Student Clubber's Data";
	}

	/**
	 * Override Parent {@link Person#getEntityWidth}
	 * Student's window width
	 * @return The Student's window width
	 */
	@Override
	protected int getEntityWidth()
	{
		return 450;
	}

	/**
	 * Override Parent {@link Person#getEntityHeight}
	 * Student's window height
	 * @return The Student's window height
	 */
	@Override
	protected int getEntityHeight()
	{
		return 250;
	}

	/**
	 * Determine if Student's ID matches with the given key.
	 * IF not try to match Student ID No.
	 * Using {@link Person#match(String)}
	 * @param key ID/Student ID No. input
	 * @return True - Key matches, False - otherwise
	 */
	public boolean match(String key)
	{
		return super.match(key) || studentID.equals(key);
	}

	/**
	 * Student's {@link javax.swing.JTextField} input text validation.
	 * Text Typed must match the specific Student's data validation
	 * ID - Name - Surname - Cellular Number as in Parent Class {@link Person#validateData}
	 * Student ID No. Format - [A-Z]{3}[1-9]\d{4}
	 * @return True - Text is in correct format False - otherwise
	 */
	protected boolean validateData()
	{
		if(!super.validateData())
			return false;
		else {
			if (!studentIDField.getText().matches("^[A-Z]{3}[1-9]\\d{4}$")) {
				studentIDSTRLB.setVisible(true);
				return false;
			} else
				studentIDSTRLB.setVisible(false);

			if (isExists(studentIDSTRLB.getText())) {
				JOptionPane.showMessageDialog(null, "Already Exists in DB");
				return false;
			}
		}

		return true;
	}

	/**
	 * IF {@link #validateData()} returns true,
	 * Saves the data from {@link javax.swing.JTextField} to Student
	 */
	protected void commit()
	{
		this.studentID = this.studentIDField.getText();
		cancelButton.setEnabled(true);
		super.commit();
	}

	/**
	 * Cancel operation, Load Student data to {@link javax.swing.JTextField}
	 * and closes the window.
	 */
	protected void rollBack()
	{
		this.studentIDField.setText(studentID);

		super.rollBack();
		studentIDSTRLB.setVisible(false);

		this.setVisible(false);
	}
	
}
