import javax.swing.*;
import javax.imageio.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.*;
import java.util.*;

/**
 * NightClubMgmtApp class extends {@link javax.swing.JFrame}.
 * Creating all GUI elements for the application's main menu.
 * @author Roy Azami and Omri Kellner
 */
public class NightClubMgmtApp extends JFrame
{
	//Night-Club Regular Customers Repository
	private static ArrayList<ClubAbstractEntity> clubbers;
	Scanner sc = new Scanner(System.in);
	JPanel compPanel;
	JButton search;
	JButton create;
	JButton exit;
	JComboBox<String> itemType;
	String[] typeNames = {"Person", "Student", "Soldier"};
	ButtonsHandler handler;
	MenuItemHandler cmbHandler;
	int indexSelected;

	/**
	 * Default Constructor, Sets the GUI window base settings.
	 * Initialize all data members
	 */
	public NightClubMgmtApp()
	{
		/*App Properties*/
		setTitle("B.K");
		setResizable(false);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setSize(450,400);
		JLabel bkground = new JLabel();
		bkground.setSize(new Dimension(450,400));
		try {
			BufferedImage iconIMG = ImageIO.read(new File("club.jpg"));
			Image img = ((BufferedImage)iconIMG).getScaledInstance(bkground.getWidth(),
					bkground.getHeight(),Image.SCALE_SMOOTH);
			ImageIcon icon = new ImageIcon(img);
			bkground = new JLabel(icon);

			setContentPane(bkground);
		} catch (IOException e) {
			e.printStackTrace();
		}

		setLayout(new BorderLayout());
		/*Screen Dimension Variable*/
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		setLocation(((dim.width - getSize().width) / 2),((dim.height - getSize().height)/2));

		/*Handlers*/
		handler = new ButtonsHandler();
		cmbHandler = new MenuItemHandler();

		/*Main Panel*/
		compPanel = new JPanel(new GridLayout(4 , 1,0,0));
		compPanel.setOpaque(false);

		/*Title Label*/
		JPanel titlePanel = new JPanel(new FlowLayout());
		JLabel title = new JLabel("B.K Club Management App", JLabel.CENTER);
		title.setFont(new Font("David", Font.BOLD,26));
		title.setSize(title.getPreferredSize());
		title.setBackground(new Color(204,0,204));
		title.setForeground(Color.BLACK);
		title.setOpaque(true);
		titlePanel.add(title);
		titlePanel.setOpaque(false);
		compPanel.add(titlePanel);

		/*Combo Box and Title Panel*/
		JPanel selectivePanel = new JPanel(new FlowLayout());
		JLabel selectTitle = new JLabel("Select Clubber:");
		selectTitle.setBackground(new Color(204,0,204));
		selectTitle.setSize(selectTitle.getPreferredSize());
		selectTitle.setFont(new Font("David",Font.BOLD,22));
		selectTitle.setForeground(Color.BLACK);
		selectTitle.setOpaque(true);
		itemType = new JComboBox<String>(typeNames);
		itemType.setPreferredSize(new Dimension(250,30));
		selectivePanel.add(selectTitle);
		selectivePanel.add(itemType);
		itemType.addItemListener(cmbHandler);
		selectivePanel.setOpaque(false);
		compPanel.add(selectivePanel);

		/*Search and Create Panel*/
		JPanel optionButtons = new JPanel(new FlowLayout());
		search = new JButton("Search");
		create = new JButton("Create New Clubber");
		search.setPreferredSize(new Dimension(150,50));
		search.addActionListener(handler);
		create.setPreferredSize(new Dimension(150, 50));
		create.addActionListener(handler);
		search.setBackground(new Color(178,102,255));
		create.setBackground(new Color(178,102,255));
		search.setForeground(Color.BLACK);
		create.setForeground(Color.BLACK);
		optionButtons.add(search);
		optionButtons.add(create);
		optionButtons.setOpaque(false);
		compPanel.add(optionButtons);

		/*Save and Exit Panel*/
		exit = new JButton("Exit");
		JPanel exitOperationPanel = new JPanel(new FlowLayout());
		exit.setPreferredSize(new Dimension(300, 80));
		exit.setFont(new Font("David", Font.BOLD, 20));
		exit.addActionListener(handler);
		exitOperationPanel.add(exit);
		exit.setBackground(new Color(178,102,255));
		exit.setForeground(Color.BLACK);
		exitOperationPanel.setOpaque(false);

		compPanel.add(exitOperationPanel);
		add(compPanel,BorderLayout.CENTER);

		setVisible(true);

		/*Init New Clubbers Array List*/
		clubbers = new ArrayList<>();

		/*Load Clubbers' DB*/
		loadClubbersDBFromFile();

	}

	/**
	 * Checks if there is any existing Clubber with a given Key
	 * Using {@link Person#match(String)} for Person, {@link Student#match(String)} for Person, {@link Soldier#match(String)} for Soldier
	 * @param key ID/Student ID/Personal No. to search
	 * @return True - Key matches, False - otherwise
	 */
	public static boolean isExists(String key)
	{
		return clubbers.stream().anyMatch(c->c.match(key));
	}

	/**
	 * Prompt for input - Key.
	 * A Clubber that has matching key will be
	 * shown on screen.
	 * Using {@link Person#match(String)} for Person, {@link Student#match(String)} for Person, {@link Soldier#match(String)} for Soldier
	 * Otherwise - corresponding message will be shown.
	 */
	private void manipulateDB()
	{
		Scanner sc = new Scanner(System.in);
		String input; boolean found = false;

		while(true)
		{
			input = JOptionPane.showInputDialog(null,"Please Enter The Clubber's Key",
					"Clubber's Search", JOptionPane.OK_CANCEL_OPTION);
			if(input == null)
				break;
			else if (input.equals(""))
			{
				JOptionPane.showMessageDialog(null,"Search Key is Empty!");
				continue;
			}

			for(ClubAbstractEntity clubber : clubbers)
				if(clubber.match(input))
				{
					found = true;
					clubber.setVisible(true);
					setEnabled(false);
					clubber.toFront();
					clubber.addWindowListener(new WindowAdapter() {
						@Override
						public void windowDeactivated(WindowEvent e) {
							if (!clubber.isVisible())
							{
								setEnabled(true);
								toFront();
							}}});
					break;
				}
				
				if(!found)
					JOptionPane.showMessageDialog(null,"Clubber with key " + input +
							" does not exist", "Search Result",JOptionPane.INFORMATION_MESSAGE);
				
				else
				{found = !found; break;}
		}
	}// End of method manipulateDB

	/**
	 * Load Clubbers from DB file into application's memory.
	 * Using {@link java.io.FileInputStream} {@link java.io.ObjectInputStream}
	 * DB File: "BKCustomers.dat"
	 */
	private void loadClubbersDBFromFile()
	{
		try {
			FileInputStream inputFile = new FileInputStream("BKCustomers.dat");
			ObjectInputStream inputObject = new ObjectInputStream(inputFile);
			clubbers = (ArrayList<ClubAbstractEntity>)inputObject.readObject();
			}
		catch (FileNotFoundException fileNotFound)
		{
			JOptionPane.showMessageDialog(null,"Couldn't Find Given File. " +
							"File will be created upon exiting the app",
					"Error",JOptionPane.ERROR_MESSAGE);
		}
		catch (IOException ioe)
		{
			JOptionPane.showMessageDialog(null,"Couldn't Read Object From File",
					"Error",JOptionPane.ERROR_MESSAGE);
			System.exit(1);
		}
		catch (ClassNotFoundException foundException)
		{
			JOptionPane.showMessageDialog(null,"ClubAbstractEntity Class Not Found",
					"Error",JOptionPane.ERROR_MESSAGE);
			System.exit(1);
		}
	}

	/**
	 * Save Clubbers from application's memory into DB File
	 * Using {@link java.io.FileOutputStream} {@link java.io.ObjectOutputStream}
	 * DB File: "BKCustomers.dat"
	 */
	private void writeClubbersDBtoFile()
	{
		//Write all the objects’ data in clubbers ArrayList into the file
		try{
			FileOutputStream outputFile = new FileOutputStream("BKCustomers.dat");
			ObjectOutputStream outputObject = new ObjectOutputStream(outputFile);

			outputObject.writeObject(clubbers);
		}
		catch (FileNotFoundException fileNotFound)
		{
			JOptionPane.showMessageDialog(null,"Couldn't Find Given File." +
							"File will be created upon exiting the app",
					"Error",JOptionPane.ERROR_MESSAGE);
			System.exit(1);
		}
		catch (IOException ioe)
		{
			JOptionPane.showMessageDialog(null,"Couldn't Write Object To File",
					"Error",JOptionPane.ERROR_MESSAGE);
			System.exit(1);
		}
	}

	/**
	 * Creates a new type of Clubber.
	 * Prompt a window to type in Clubber's INFO
	 */
	private void createNewClubber() {

		ClubAbstractEntity clubber = null;

		switch(indexSelected)
		{
			case 0:
				clubber = new Person("","","","");
				break;
			case 1:
				clubber = new Student("","","","","");
				break;
			case 2:
				clubber = new Soldier("","","","","");
				break;
		}

		clubber.setVisible(true);
		final ClubAbstractEntity newClubber = clubber;

		setEnabled(false);
		clubber.addWindowListener(new WindowAdapter() {
			@Override
			public void windowDeactivated(WindowEvent e) {
				if(!newClubber.isVisible())
				{
					clubbers.add(newClubber);
					setEnabled(true);
					toFront();
				}}}
		);
	}

	/**
	 * Handler for Undo and Clear button press. Implements {@link java.awt.event.ActionListener}
	 */
	private class ButtonsHandler implements ActionListener
	{
		/**
		 * Defines the behaviour of button press action.
		 * @param event ActionEvent button action event
		 */
		@Override
		public void actionPerformed (ActionEvent event)
		{
			if (event.getSource() == exit) {
				writeClubbersDBtoFile();
				System.exit(0);
			}
			else if (event.getSource() == search)
				manipulateDB();
			else  if (event.getSource() == create)
				createNewClubber();
		}
	}

	/**
	 * Handler for Combo Box events. Implements {@link java.awt.event.ItemListener}
	 * Updates the correct values according to changes made on the above tools.
	 */
	private class MenuItemHandler implements ItemListener
	{
		/**
		 * Define the behaviour of a change in the Combo / Check Boxes.
		 * @param event ItemEvent
		 */
		@Override
		public void itemStateChanged(ItemEvent event)
		{
			if(event.getSource() == itemType)
				indexSelected = itemType.getSelectedIndex();
		}
	}


	/**
	 * Main Program Method, Opens CLubbers Application
	 * @param args Application Activation Parameters - Disabled
	 */
	public static void main(String[] args)
	{
		NightClubMgmtApp appliction = new NightClubMgmtApp();
	}
	
}//End of class NightClubMgmtApp
