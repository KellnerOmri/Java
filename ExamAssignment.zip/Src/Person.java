import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

/**
 * Person class extends {@link ClubAbstractEntity}.
 * Creating all GUI elements and data for the Person window.
 * Elements will be orgenized by the given assignment layout.
 * @author Roy Azami and Omri Kellner
 */
public class Person extends ClubAbstractEntity {

    protected String id;
    protected String name;
    protected String surname;
    protected String cellNumber;
    protected JTextField[] fieldTxt;
    protected JLabel[] strLBL;
    protected String[] lblTitles = {"ID", "Name", "Surname", "Tel"};
    protected String[] re;

    /**
     * Parameterized Constructor
	 * Using super constructor {@link ClubAbstractEntity}
     * @param id Person's ID Number
     * @param name Person's Name
     * @param surname Person's Surname
     * @param cellNumber Person's Cellular Number
     */
    Person(String id, String name, String surname, String cellNumber)
    {
        /* Frame Properties */
        setTitle(getEntityTitle());
        setResizable(false);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setSize(getEntityWidth(), getEntityHeight());
        initEntityLayout();
        /*Screen Dimension Variable*/
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        setLocation(((dim.width - getSize().width) / 2),((dim.height - getSize().height)/2));

        /*Initialize Instance Variables*/
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.cellNumber = cellNumber;

        /*Initialize RE for this Class*/
        re = new String[4];
        re[0] = "^\\d-\\d{7}\\|[1-9]$";
        re[1] = "^[A-Z][a-z]+$";
        re[2] = "^([A-Z][a-z]*[-']?)+$";
        re[3] = "^\\+\\([1-9]\\d{0,2}\\)\\d{1,3}-[1-9]\\d{6}$";

        initTextComponent();
    }

    /**
     * Sets Person's window GUI components layout.
	 * Using super method {@link ClubAbstractEntity#addToCenter(Component)}
     * Adds the layout to the Central Panel
     */
    protected void initEntityLayout() {
        centerPanel = new JPanel(new GridLayout(4,1,0,10));
        add(centerPanel, BorderLayout.CENTER);
    }

    /**
     * Initialize the components on Person's window
     * Organizing components in their type arrays
     */
    private void initTextComponent()
    {
        fieldTxt = new JTextField[4];
        JLabel[] titleLBL = new JLabel[4];
        strLBL = new JLabel[4];
        JPanel[] lines = new JPanel[4];

        fieldTxt[0] = new JTextField(this.id);
        fieldTxt[1] = new JTextField(this.name);
        fieldTxt[2] = new JTextField(this.surname);
        fieldTxt[3] = new JTextField(this.cellNumber);

        for (int i = 0; i < fieldTxt.length; i++)
        {
            fieldTxt[i].setPreferredSize(new Dimension(335,25));
            titleLBL[i] = new JLabel(lblTitles[i], JLabel.RIGHT);
            titleLBL[i].setPreferredSize(new Dimension(80, 25));
            strLBL[i] = new JLabel("*");
            strLBL[i].setForeground(Color.red);
            strLBL[i].setPreferredSize(new Dimension(10,25));
            strLBL[i].setVisible(false);
        }

        for(int i = 0; i < lines.length; i++)
        {
            lines[i]  = new JPanel(new FlowLayout());
            lines[i].add(titleLBL[i]);
            lines[i].add(fieldTxt[i]);
            lines[i].add(strLBL[i]);

            addToCenter(lines[i]);
        }
    }

    /**
     * Return the Person's window title
     * @return The Person's window title
     */
    protected String getEntityTitle()
    {
        return "Person Clubber's Data";
    }

    /**
     * Return the Person's window height
     * @return The Person's window width
     */
    protected int getEntityWidth()
    {
        return 450;
    }

    /**
     * Return the Person's window height
     * @return The Person's window width
     */
    protected int getEntityHeight()
    {
        return 220;
    }

    /**
     * Determine if Person's ID matches with the given key.
     * @param key Person ID input
     * @return True - Key matches, False - otherwise
     */
    public boolean match(String key)
    {
        return this.id.equals(key);
    }

    /**
     * Person's {@link javax.swing.JTextField} input text validation.
     * Text Typed must match the specific Person's data validation <br>
     * ID Format: \d-\d{7}\|[1-9] <br>
     * Name Format: [A-Z][a-z]+ <br>
     * Surname Format: ([A-Z][a-z]*[-']?)+ <br>
     * Cellular Number Format: \+\([1-9]\d{0,2}\)\d{1,3}-[1-9]\d{6}
     * @return True - Text is in correct format False - otherwise
     */
    protected boolean validateData() {
        for (int i =0; i < fieldTxt.length; i++)
        {
            if(!fieldTxt[i].getText().matches(re[i]))
            {
                strLBL[i].setVisible(true);
                return false;
            }
            else
                strLBL[i].setVisible(false);
        }

        if(isExists(fieldTxt[0].getText()) && !cancelButton.isEnabled())
        {
            JOptionPane.showMessageDialog(null,"Already Exists in DB");
            return false;
        }

        return true;
    }


    /**
     * Checks if there is any existing Clubber with a given Key
	 * Using static method {@link NightClubMgmtApp#isExists}
     * @param key Person's ID or Student ID if type is child {@link Student}/Personal No. if type is child {@link Soldier}
     * @return True - Key matches, False - otherwise
     */
    protected boolean isExists(String key)
    {
        return NightClubMgmtApp.isExists(key);
    }

    /**
     * IF {@link #validateData()} returns true,
     * Saves the data from {@link javax.swing.JTextField} to Person
     */
    protected void commit()
    {
        if(!this.validateData())
            return;

        this.id = this.fieldTxt[0].getText();
        this.name = this.fieldTxt[1].getText();
        this.surname = this.fieldTxt[2].getText();
        this.cellNumber = this.fieldTxt[3].getText();

        cancelButton.setEnabled(true);
        setVisible(false);
    }

    /**
     * Cancel operation, Load Person data to {@link javax.swing.JTextField}
     * and closes the window.
     */
    protected void rollBack()
    {
        this.fieldTxt[0].setText(this.id);
        this.fieldTxt[1].setText(this.name);
        this.fieldTxt[2].setText(this.surname);
        this.fieldTxt[3].setText(cellNumber);

        for (JLabel lbl: strLBL) {
            lbl.setVisible(false);
        }

        this.setVisible(false);
    }
}
