import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.Serializable;

/**
 * Abstract Class ClubAbstractEntity extends {@link javax.swing.JFrame}.
 * Implements Serializable {@link java.io.Serializable}
 * Sets the base GUI window layout for Child Clubber
 * and the base behavior.
 * @author Roy Azami and Omri Kellner
 */
public abstract class ClubAbstractEntity extends JFrame implements Serializable
{
    protected final JPanel buttonsPanel;
    protected JButton okButton;
    protected JButton cancelButton;
    protected JPanel centerPanel;
    protected ButtonsHandler handler;


    /**
     * Default Constructor, Sets the GUI window base settings.
     * Adds handlers to the buttons on the base window layout.
     */
    ClubAbstractEntity()
    {
        /*App Properties*/
        setResizable(false);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLayout(new BorderLayout());

        /*Buttons*/
        buttonsPanel = new JPanel();
        okButton = new JButton("Ok");
        cancelButton = new JButton("Cancel");
        buttonsPanel.add(okButton);
        buttonsPanel.add(cancelButton);
        add(buttonsPanel, BorderLayout.SOUTH);

        /*Button Handler*/
        handler = new ButtonsHandler();
        okButton.addActionListener(handler);
        cancelButton.addActionListener(handler);
        cancelButton.setEnabled(false);

        /*Center Panel*/
        centerPanel = new JPanel();
        add(centerPanel, BorderLayout.CENTER);
    }

    /**
     * Adds GUI elements to the center of the window.
     * @param guiComponent Componenet to be added to central panel
     */
    protected void addToCenter(Component guiComponent)
    {
        centerPanel.add(guiComponent);
    }

    /**
     * Abstract method. Determine if Clubber key matches with the given key.
     * @param key The key to search
     * @return True - Key matches, False - otherwise
     */
    public abstract boolean match(String key);

    /**
     * Abstract method. {@link javax.swing.JTextField} input text validation.
     * Text Typed must match the specific Clubber's data validation
     * @return True - Text is in correct format False - otherwise
     */
    protected abstract boolean validateData();

    /**
     * Abstract Method. Saves {@link javax.swing.JTextField} to the
     * specific Clubber's object members.
     */
    protected abstract void commit();

    /**
     * Abstract Method. Reload data from Clubber's object to {@link javax.swing.JTextField}
     * and closes the window.
     */
    protected abstract void rollBack();

    /**
     * Handler for Undo and Clear button press. Implements {@link java.awt.event.ActionListener}
     */
    private class ButtonsHandler implements ActionListener, Serializable
    {
        /**
         * Defines the behaviour of button press action.
         * @param event ActionEvent button action event
         */
        @Override
        public void actionPerformed (ActionEvent event)
        {
            if (event.getSource() == okButton) {
                if (validateData())
                    commit();

            }
            else if (event.getSource() == cancelButton)
                rollBack();
        }
    }



}
