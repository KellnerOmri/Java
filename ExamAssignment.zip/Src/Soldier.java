import javax.swing.*;
import java.awt.*;

/**
 * Soldier class extends {@link Person}.
 * Creating all GUI elements and data for the Soldier's window.
 * Elements will be orgenized by the given assignment layout.
 * @author Roy Azami and Omri Kellner
 */
public class Soldier extends Person {
	private String personalNum;
	JTextField personalNumField;
	JLabel personalNumSTRLBL;

	/**
	 * Parameterized Constructor
	 * @param id Soldiers's ID Number
	 * @param name Soldiers's Name
	 * @param surname Soldiers's Surname
	 * @param cellNumber Soldiers's Cellular Number
	 * @param personalNum Soldiers's Personal No.
	 */
	Soldier(String id, String name, String surname, String cellNumber, String personalNum)
	{
		/*Person Constructor Call*/
		super(id, name, surname, cellNumber);
		this.personalNum = personalNum;

		/*Initialize Instance Variables*/
		JPanel line = new JPanel(new FlowLayout());

		JLabel personalNumLBL = new JLabel("Personal No. ", JLabel.RIGHT);
		personalNumLBL.setPreferredSize(new Dimension(80, 25));

		personalNumField = new JTextField(personalNum);
		personalNumField.setPreferredSize(new Dimension(335,25));

		personalNumSTRLBL = new JLabel("*");
		personalNumSTRLBL.setForeground(Color.red);
		personalNumSTRLBL.setPreferredSize(new Dimension(10,25));
		personalNumSTRLBL.setVisible(false);

		line.add(personalNumLBL);
		line.add(personalNumField);
		line.add(personalNumSTRLBL);

		addToCenter(line);
	}

	/**
	 * Override Parent {@link Person#initEntityLayout}
	 * Sets Soldier's window GUI components layout.
	 * Adds the layout to the Central Panel
	 */
	@Override
	protected void initEntityLayout() {
		centerPanel = new JPanel(new GridLayout(5,1,0,10));
		add(centerPanel, BorderLayout.CENTER);
	}

	/**
	 * Override Parent {@link Person#getEntityTitle}
	 * Soldier's window title
	 * @return The Soldier's window title
	 */
	@Override
	protected String getEntityTitle()
	{
		return "Soldier Clubber's Data";
	}

	/**
	 * Override Parent {@link Person#getEntityWidth}
	 * Soldier's window width
	 * @return The Soldier's window width
	 */
	@Override
	protected int getEntityWidth()
	{
		return 450;
	}

	/**
	 * Override Parent {@link Person#getEntityHeight}
	 * Soldier's window height
	 * @return The Soldier's window height
	 */
	@Override
	protected int getEntityHeight()
	{
		return 250;
	}

	/**
	 * Determine if Soldier's ID matches with the given key.
	 * IF not try to match Personal No.
	 * Using {@link Person#match(String)}
	 * @param key Soldier ID/Personal No. input
	 * @return True - Key matches, False - otherwise
	 */
	public boolean match(String key)
	{
		return super.match(key) || personalNum.equals(key);
	}

	/**
	 * Soldier's {@link javax.swing.JTextField} input text validation.
	 * Text Typed must match the specific Soldier's data validation
	 * ID - Name - Surname - Cellular Number as in Parent Class {@link Person#validateData}
	 * Personal No. Format - [ROC]/[1-9]\d{6}
	 * @return True - Text is in correct format False - otherwise
	 */
	protected boolean validateData()
	{
		if(!super.validateData())
			return  false;
		else{
			if(!personalNumField.getText().matches("^[ROC]/[1-9]\\d{6}$"))
			{
				personalNumSTRLBL.setVisible(true);
				return false;
			}
			else
				personalNumSTRLBL.setVisible(false);

			if (isExists(personalNumField.getText()))
			{
				JOptionPane.showMessageDialog(null,"Already Exists in DB");
				return false;
			}
		}
		return true;
	}

	/**
	 * IF {@link #validateData()} returns true,
	 * Saves the data from {@link javax.swing.JTextField} to Soldier
	 */
	protected void commit()
	{
		super.commit();
		cancelButton.setEnabled(true);
		this.personalNum = this.personalNumField.getText();
	}

	/**
	 * Cancel operation, Load Soldier data to {@link javax.swing.JTextField}
	 * and closes the window.
	 */
	protected void rollBack()
	{
		super.rollBack();
		
		this.personalNumField.setText(personalNum);
		personalNumSTRLBL.setVisible(false);

		this.setVisible(false);
	}
}
